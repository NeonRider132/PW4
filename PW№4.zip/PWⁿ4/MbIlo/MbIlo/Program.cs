﻿Mailing ObserverWard = new Mailing("Вижн для мида", 25,"Observer Ward");
Mailing Mango = new Mailing("Мана", 80,"Enchanted Mango");
MailService courier = new MailService("Курьер", 30);
courier.Send_Mailing(ObserverWard);
courier.Send_Mailing(Mango);
Console.ReadKey(true);
class Mailing
{
    public string MailName { get; set; }
    public string Desc { get; private set; }
    public int Weight { get; set; }
    public Mailing(string desc, int weight, string mailname)
    {
        MailName = mailname;
        Desc = desc;
        Weight = weight;
    }
    public void Use() { Console.WriteLine(Weight); }
}
class MailService
{
    public string Name { get; private set; }
    private int WLimit { get; set; }
    public MailService(string name, int wlimit)
    {
        Name = name;
        WLimit = wlimit;
    }
    public void Send_Mailing(Mailing mailing)
    {
        if ((WLimit + mailing.Weight) <= 100)
        {
            Console.WriteLine("Отправлена посылка " + mailing.MailName);
            WLimit += mailing.Weight;
        }
        else 
        { 
            Console.WriteLine("Вес отправленных предметов превысил допустимое значение");
        }
    }
}
