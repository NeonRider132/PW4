﻿Spell MassSerpentWard = new Spell(200, "Змейки появились!", "Mass Serpent Ward");
Spell Shackles = new Spell(140, "Шаманчик связывай!", "Shackles");
Magician ShadowShaman = new Magician("Shadow Shaman", 340);
ShadowShaman.CastSpell(MassSerpentWard);
ShadowShaman.CastSpell(Shackles);
Console.ReadKey(true);
class Spell
{
   public string SpellName { get; private set; }
    public int Mana { get; private set; }
    private string Effect { get; set; }
    public Spell(int mana, string effect , string spellname)
    {
        SpellName = spellname;
        Mana = mana;
        Effect = effect;
    }
    public void Use() { Console.WriteLine(Effect); }
}
class Magician
{
    public string Name { get; private set; }
    public int Mana { get; private set; }
    public Magician(string name, int mana)
    {
        Name = name;
        Mana = mana;
    }
    public void CastSpell(Spell spell)
    {
        if (Mana >= spell.Mana)
        {
            Console.WriteLine(Name + " шаманит!" + spell.SpellName);
            spell.Use(); Mana -= spell.Mana;
        }
        else
        {
            Console.WriteLine("Для испольования " + spell + " не хватает " + (Math.Abs(spell.Mana - Mana)) + " маны." +//названия заклинаний никак не отображаются
            " Съешьте манго или выпей кларити!");
        }
    }
}




